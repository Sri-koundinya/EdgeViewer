const img = document.getElementById('frame');
const stats = document.getElementById('stats');
img.onload = () => {
  stats.innerHTML = `FPS: N/A<br/>Resolution: ${img.naturalWidth}x${img.naturalHeight}`;
};
let last = performance.now();
function tick() {
  const now = performance.now();
  const fps = (1000.0 / (now - last)).toFixed(1);
  stats.innerHTML = `FPS: ${fps}<br/>Resolution: ${img.naturalWidth}x${img.naturalHeight}`;
  last = now;
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);
