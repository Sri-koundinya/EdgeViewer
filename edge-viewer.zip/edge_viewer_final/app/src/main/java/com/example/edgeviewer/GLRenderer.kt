//package com.example.edgeviewer
//
//import android.content.Context
//import android.graphics.SurfaceTexture
//import android.opengl.GLES20
//import android.opengl.GLUtils
//import java.nio.ByteBuffer
//import java.nio.ByteOrder
//import java.nio.FloatBuffer
//
//class GLRenderer(private val context: Context) {
//    private var textureId = -1
//    private var program = 0
//    private var surfaceTexture: SurfaceTexture? = null
//    private var width = 0
//    private var height = 0
//
//    private val vertexShaderCode = """
//        attribute vec4 aPosition;
//        attribute vec2 aTexCoord;
//        varying vec2 vTexCoord;
//        void main() {
//            gl_Position = aPosition;
//            vTexCoord = aTexCoord;
//        }
//    """.trimIndent()
//
//    private val fragmentShaderCode = """
//        precision mediump float;
//        varying vec2 vTexCoord;
//        uniform sampler2D uTexture;
//        void main() {
//            gl_FragColor = texture2D(uTexture, vTexCoord);
//        }
//    """.trimIndent()
//
//    private val vertexCoords = floatArrayOf(
//        -1f,  1f,   0f, 0f,
//        -1f, -1f,   0f, 1f,
//         1f, -1f,   1f, 1f,
//         1f,  1f,   1f, 0f
//    )
//
//    private val vb: FloatBuffer = ByteBuffer.allocateDirect(vertexCoords.size * 4)
//        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(vertexCoords); position(0) }
//
//    fun onSurfaceCreated(surface: SurfaceTexture) {
//        this.surfaceTexture = surface
//        initGL()
//    }
//
//    private fun initGL() {
//        program = createProgram(vertexShaderCode, fragmentShaderCode)
//        textureId = createTexture()
//        GLES20.glUseProgram(program)
//    }
//
//    fun updateTextureFromRGBA(rgbaBytes: ByteArray, w: Int, h: Int) {
//        width = w; height = h
//        try {
//            val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
//            bmp.copyPixelsFromBuffer(ByteBuffer.wrap(rgbaBytes))
//            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
//            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
//            drawFrame()
//        } catch (e: Exception) {
//        }
//    }
//
//    private fun drawFrame() {
//        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
//        val pos = GLES20.glGetAttribLocation(program, "aPosition")
//        val tc = GLES20.glGetAttribLocation(program, "aTexCoord")
//        vb.position(0); GLES20.glEnableVertexAttribArray(pos); GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 16, vb)
//        vb.position(2); GLES20.glEnableVertexAttribArray(tc); GLES20.glVertexAttribPointer(tc, 2, GLES20.GL_FLOAT, false, 16, vb)
//        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
//        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
//        val uTex = GLES20.glGetUniformLocation(program, "uTexture")
//        GLES20.glUniform1i(uTex, 0)
//        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4)
//        GLES20.glDisableVertexAttribArray(pos); GLES20.glDisableVertexAttribArray(tc)
//    }
//
//    private fun createTexture(): Int {
//        val tex = IntArray(1)
//        GLES20.glGenTextures(1, tex, 0)
//        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
//        GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR.toFloat())
//        GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR.toFloat())
//        GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE.toFloat())
//        GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE.toFloat())
//        return tex[0]
//    }
//
//    private fun loadShader(type:Int, shaderCode:String):Int {
//        val shader = GLES20.glCreateShader(type)
//        GLES20.glShaderSource(shader, shaderCode)
//        GLES20.glCompileShader(shader)
//        return shader
//    }
//    private fun createProgram(vs:String, fs:String): Int {
//        val v = loadShader(GLES20.GL_VERTEX_SHADER, vs)
//        val f = loadShader(GLES20.GL_FRAGMENT_SHADER, fs)
//        val p = GLES20.glCreateProgram()
//        GLES20.glAttachShader(p, v); GLES20.glAttachShader(p, f)
//        GLES20.glLinkProgram(p)
//        return p
//    }
//
//    fun onSurfaceDestroyed() {
//    }
//}

package com.example.edgeviewer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Bitmap.Config
import android.opengl.GLES20
import android.util.Log

/**
 * Minimal GLRenderer stub so the project compiles and can display processed frames.
 * This is NOT an optimized GL renderer — it's a small placeholder that accepts RGBA bytes.
 */
class GLRenderer(private val context: Context) {

    private val TAG = "GLRenderer"

    // Called by MainActivity to update texture from RGBA bytes (w * h * 4 bytes)
    fun updateTextureFromRGBA(rgbaBytes: ByteArray, width: Int, height: Int) {
        try {
            // Convert the RGBA byte array to a Bitmap (for demo only)
            val bmp = Bitmap.createBitmap(width, height, Config.ARGB_8888)
            // copy pixels (fast path)
            bmp.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(rgbaBytes))
            // In a real renderer you would upload bmp to GL texture — here we only log
            Log.d(TAG, "Received RGBA bitmap ${bmp.width}x${bmp.height}")
            // recycle to avoid memory leak in demo
            bmp.recycle()
        } catch (t: Throwable) {
            Log.e(TAG, "updateTextureFromRGBA failed: $t")
        }
    }

    // Release any resources (if any)
    fun release() {
        // nothing to release in the stub
        Log.d(TAG, "GLRenderer.release called")
    }
}

