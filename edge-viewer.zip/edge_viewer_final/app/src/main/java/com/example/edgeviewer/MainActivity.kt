package com.example.edgeviewer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.os.Bundle
import android.util.Log
import android.util.Size
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.os.Handler
import android.os.Looper
import androidx.camera.view.PreviewView

class MainActivity : AppCompatActivity() {
    private val TAG = "MainActivity"
    private lateinit var previewView: PreviewView
    private lateinit var renderer: GLRenderer

    companion object {
        init {
            // Load OpenCV runtime first (if present)
            try {
                System.loadLibrary("opencv_java4")
                Log.i("MainActivity", "Loaded libopencv_java4")
            } catch (t: Throwable) {
                Log.e("MainActivity", "Failed to load opencv_java4: $t")
            }

            // Then load native lib
            try {
                System.loadLibrary("native-lib")
                Log.i("MainActivity", "Loaded native-lib")
            } catch (t: Throwable) {
                Log.e("MainActivity", "Failed to load native-lib: $t")
            }
        }
    }

    // JNI native function (must match the C++ signature)
    external fun processFrameNative(bytes: ByteArray, w: Int, h: Int): ByteArray?

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startCameraSafe()
            } else {
                Toast.makeText(this, "Camera permission required", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        renderer = GLRenderer(this)

        // Request permission or start camera if already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            startCameraSafe()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Start CameraX only after permission is granted.
    private fun startCameraSafe() {
        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()

                // Preview use case
                val preview = Preview.Builder()
                    .setTargetResolution(Size(640, 480))
                    .build()
                preview.setSurfaceProvider(previewView.surfaceProvider)

                // Analyzer
                val analyzer = ImageAnalysis.Builder()
                    .setTargetResolution(Size(640, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                analyzer.setAnalyzer(ContextCompat.getMainExecutor(this)) { image: ImageProxy ->
                    // We will use a background coroutine for native processing
                    try {
                        val nv21 = imageProxyToNV21(image)
                        // Launch background work
                        GlobalScope.launch(Dispatchers.Default) {
                            try {
                                val processed: ByteArray? = try {
                                    processFrameNative(nv21, image.width, image.height)
                                } catch (t: Throwable) {
                                    Log.e(TAG, "Native processing exception: $t")
                                    null
                                }

                                if (processed != null && processed.isNotEmpty()) {
                                    // Post update to GLRenderer on main thread
                                    Handler(Looper.getMainLooper()).post {
                                        try {
                                            renderer.updateTextureFromRGBA(processed, image.width, image.height)
                                        } catch (t: Throwable) {
                                            Log.e(TAG, "Renderer update failed: $t")
                                        }
                                    }
                                } else {
                                    // Optional: fallback behavior if native returned null
                                    Log.w(TAG, "Processed frame is null or empty")
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "Processing coroutine error: ${e.message}")
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "analyzer conversion error: ${e.message}")
                    } finally {
                        // Always close the image
                        try {
                            image.close()
                        } catch (t: Throwable) {
                            Log.w(TAG, "Failed to close image: $t")
                        }
                    }
                }

                // Bind to lifecycle
                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(this as LifecycleOwner, cameraSelector, preview, analyzer)
                } catch (e: Exception) {
                    Log.e(TAG, "Camera bind failed", e)
                    Toast.makeText(this, "Camera bind failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }, ContextCompat.getMainExecutor(this))
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start camera: $e")
            Toast.makeText(this, "Camera startup error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun imageProxyToNV21(image: ImageProxy): ByteArray {
        val format = image.format
        if (format != ImageFormat.YUV_420_888) {
            throw IllegalArgumentException("Expected YUV_420_888 image")
        }
        val planes = image.planes
        val yPlane = planes[0]
        val uPlane = planes[1]
        val vPlane = planes[2]

        val ySize = yPlane.buffer.remaining()
        val uSize = uPlane.buffer.remaining()
        val vSize = vPlane.buffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        // copy Y
        yPlane.buffer.get(nv21, 0, ySize)

        // copy interleaved VU (NV21) from planes V and U
        val chromaStart = ySize
        val vBytes = ByteArray(vSize)
        val uBytes = ByteArray(uSize)
        vPlane.buffer.get(vBytes)
        uPlane.buffer.get(uBytes)
        var i = 0
        while (i < vBytes.size && i < uBytes.size) {
            val outIndex = chromaStart + i * 2
            if (outIndex + 1 < nv21.size) {
                nv21[outIndex] = vBytes[i]
                nv21[outIndex + 1] = uBytes[i]
            }
            i++
        }
        return nv21
    }

    override fun onDestroy() {
        super.onDestroy()
        // any renderer cleanup if needed
        try {
            renderer.release()
        } catch (t: Throwable) {
            Log.w(TAG, "Renderer release failed: $t")
        }
    }
}
