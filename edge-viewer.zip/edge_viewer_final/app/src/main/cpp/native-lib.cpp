//#include <jni.h>
//#include <string>
//#include <android/log.h>
//#include <opencv2/opencv.hpp>
//
//#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "native-lib", __VA_ARGS__)
//#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "native-lib", __VA_ARGS__)
//
//// NOTE: the JNI function name must match your package + class + method name exactly.
//// Our Kotlin declares: external fun processFrameNative(bytes: ByteArray, w: Int, h: Int): ByteArray
//// Package: com.example.edgeviewer
//extern "C"
//JNIEXPORT jbyteArray JNICALL
//Java_com_example_edgeviewer_MainActivity_processFrameNative(JNIEnv* env, jclass /* clazz */,
//                                                            jbyteArray inputBytes,
//                                                            jint width, jint height) {
//    if (inputBytes == nullptr) {
//        LOGE("inputBytes is null");
//        return nullptr;
//    }
//
//    // Get byte array contents from Java
//    jboolean isCopy = JNI_FALSE;
//    jbyte* input = env->GetByteArrayElements(inputBytes, &isCopy);
//    if (input == nullptr) {
//        LOGE("Failed to get byte array elements");
//        return nullptr;
//    }
//
//    // NV21 buffer size = height + height/2 rows, width columns
//    const int yuvHeight = height + height / 2;
//    cv::Mat yuv(yuvHeight, width, CV_8UC1, reinterpret_cast<unsigned char*>(input));
//
//    cv::Mat bgr;
//    try {
//        // Convert NV21 (YUV420sp) to BGR
//        cv::cvtColor(yuv, bgr, cv::COLOR_YUV2BGR_NV21);
//    } catch (const cv::Exception& e) {
//        LOGE("OpenCV cvtColor failure: %s", e.what());
//        env->ReleaseByteArrayElements(inputBytes, input, 0);
//        return nullptr;
//    }
//
//    cv::Mat gray, edges;
//    cv::cvtColor(bgr, gray, cv::COLOR_BGR2GRAY);
//    cv::GaussianBlur(gray, gray, cv::Size(5,5), 1.5);
//    cv::Canny(gray, edges, 50, 150);
//
//    cv::Mat rgba;
//    cv::cvtColor(edges, rgba, cv::COLOR_GRAY2RGBA);
//
//    // Create Java byte array for RGBA data
//    int outSize = static_cast<int>(rgba.total() * rgba.elemSize());
//    jbyteArray out = env->NewByteArray(outSize);
//    if (out == nullptr) {
//        LOGE("Failed to allocate output byte array");
//        env->ReleaseByteArrayElements(inputBytes, input, 0);
//        return nullptr;
//    }
//
//    env->SetByteArrayRegion(out, 0, outSize, reinterpret_cast<const jbyte*>(rgba.data));
//
//    // Release input array
//    env->ReleaseByteArrayElements(inputBytes, input, JNI_ABORT); // no need to copy back
//
//    return out;
//}

#include <jni.h>
#include <string>
#include <android/log.h>
#include <opencv2/opencv.hpp>

#define TAG "native-lib"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_example_edgeviewer_MainActivity_processFrameNative(JNIEnv* env, jclass /*clazz*/,
                                                            jbyteArray inputBytes,
                                                            jint width, jint height) {
    if (inputBytes == nullptr) {
        LOGE("inputBytes is null");
        return nullptr;
    }

    jboolean isCopy = JNI_FALSE;
    jbyte* input = env->GetByteArrayElements(inputBytes, &isCopy);
    if (input == nullptr) {
        LOGE("GetByteArrayElements returned null");
        return nullptr;
    }

    try {
        const int yuvHeight = height + height / 2;
        if (width <= 0 || height <= 0) {
            LOGE("Invalid width/height: %d x %d", width, height);
            env->ReleaseByteArrayElements(inputBytes, input, JNI_ABORT);
            return nullptr;
        }

        cv::Mat yuv(yuvHeight, width, CV_8UC1, reinterpret_cast<unsigned char*>(input));
        if (yuv.empty()) {
            LOGE("YUV mat empty");
            env->ReleaseByteArrayElements(inputBytes, input, JNI_ABORT);
            return nullptr;
        }

        cv::Mat bgr;
        cv::cvtColor(yuv, bgr, cv::COLOR_YUV2BGR_NV21);

        cv::Mat gray, edges;
        cv::cvtColor(bgr, gray, cv::COLOR_BGR2GRAY);
        cv::GaussianBlur(gray, gray, cv::Size(5,5), 1.5);
        cv::Canny(gray, edges, 50, 150);

        cv::Mat rgba;
        cv::cvtColor(edges, rgba, cv::COLOR_GRAY2RGBA);

        int outSize = static_cast<int>(rgba.total() * rgba.elemSize());
        jbyteArray out = env->NewByteArray(outSize);
        if (out == nullptr) {
            LOGE("Failed to allocate output array");
            env->ReleaseByteArrayElements(inputBytes, input, JNI_ABORT);
            return nullptr;
        }

        env->SetByteArrayRegion(out, 0, outSize, reinterpret_cast<const jbyte*>(rgba.data));
        env->ReleaseByteArrayElements(inputBytes, input, JNI_ABORT);
        return out;
    } catch (const cv::Exception& e) {
        LOGE("OpenCV exception: %s", e.what());
        env->ReleaseByteArrayElements(inputBytes, input, JNI_ABORT);
        return nullptr;
    } catch (const std::exception& e) {
        LOGE("std::exception: %s", e.what());
        env->ReleaseByteArrayElements(inputBytes, input, JNI_ABORT);
        return nullptr;
    } catch (...) {
        LOGE("Unknown native exception");
        env->ReleaseByteArrayElements(inputBytes, input, JNI_ABORT);
        return nullptr;
    }
}
