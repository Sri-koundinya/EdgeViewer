# Edge Viewer - Final Submission (Ready)

This project is a ready-to-open Android + native + web skeleton for the assignment.

## What is included
- Android app (CameraX) that streams camera frames to native C++ (OpenCV) and displays processed RGBA via OpenGL.
- Native C++ file (`native-lib.cpp`) implementing NV21 -> BGR -> Gray -> Canny -> RGBA.
- `CMakeLists.txt` with a placeholder `OpenCV_DIR` — **you must set this to your OpenCV SDK path**.
- Web viewer (`web/`) with `processed_frame.png` placeholder and a small FPS overlay script.
- Gradle files so you can open the project root in Android Studio.

## How to set OpenCV path
1. Download OpenCV Android SDK and unzip it.
2. Edit `app/src/main/cpp/CMakeLists.txt` and change `set(OpenCV_DIR "...")` to your `sdk/native/jni` path.

## Build & Run (summary)
1. Open the project root in Android Studio.
2. Install NDK and CMake via SDK Manager if not installed.
3. Connect an Android device. Run the app. Grant Camera permission.
4. The app uses CameraX and will show processed edges (if native lib linked correctly).

## Capture processed frame for the web viewer
Use ADB to capture current screen:
  adb exec-out screencap -p > processed_screen.png
Copy `processed_screen.png` to `web/assets/processed_frame.png` to update the web viewer.

